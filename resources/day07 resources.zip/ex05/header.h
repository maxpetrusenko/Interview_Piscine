#ifndef HEADER_H
# define HEADER_H

/*--------------------------------
  !! required structure
  --------------------------------*/


/*--------------------------------
  :) function you must implement
  --------------------------------*/

char *neverForget(char *words, char **dictionary);


/*--------------------------------
  ?? test function used in main 
  --------------------------------*/

extern char *g_dict[];

char *get_content(char *file);


/*--------------------------------
  &  your own other function
  --------------------------------*/


#endif
