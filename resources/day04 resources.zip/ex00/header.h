#ifndef HEADER_H
# define HEADER_H

/*--------------------------------
  !! required structure
  --------------------------------*/


/*--------------------------------
  :) function you must implement
  --------------------------------*/
char *getSum(char *a, char *b);
int toInt(char *bits);

/*--------------------------------
  ?? test function used in main 
  --------------------------------*/
int checkBinary(char *str);

/*--------------------------------
  &  your own other function
  --------------------------------*/


#endif
